package com.tang.bottomnavigation.bottomnavigation.otheractivity;

import java.util.Timer;
import java.util.TimerTask;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.tang.bottomnavigation.bottomnavigation.R;

/**
 * 实现Android计时器功能2 计时器控件交互
 */
public class JiShiQiLinearlayout extends LinearLayout {
    private EditText etHour, etMin, etSec;
    private Button btnStart, btnPause
            //, btnResume, btnReset
            ;

            public JiShiQiLinearlayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    /**
     * xml布局资源使用
     */
    public JiShiQiLinearlayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    /**
     * 程序使用
     */
    public JiShiQiLinearlayout(Context context) {
        super(context);
    }

    /**
     * 相当于oncreate方法
     */
    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        initView();//舒适化控件
        myOnclick();//监听事件方法

    }

    /**
     * 监听事件方法
     */
    private void myOnclick() {
        etHour.setText("00");
        etMin.setText("00");
        etSec.setText("00");
        btnStart.setVisibility(View.VISIBLE);
        btnStart.setEnabled(false);
        btnPause.setVisibility(View.GONE);
        //btnResume.setVisibility(View.GONE);
        //btnReset.setVisibility(View.GONE);
        /*
         * 小时监听
         */
        etHour.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());

                    if (value > 59) {
                        etHour.setText("59");
                    } else if (value < 0) {
                        etHour.setText("0");
                    }
                    checkToAbleStartBtn();
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        /*
         * 分钟监听
         */
        etMin.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());

                    if (value > 59) {
                        etMin.setText("59");
                    } else if (value < 0) {
                        etMin.setText("0");
                    }
                    checkToAbleStartBtn();
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        /*
         * 秒钟监听
         */
        etSec.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());

                    if (value > 59) {
                        etSec.setText("59");
                    } else if (value < 0) {
                        etSec.setText("0");
                    }
                    checkToAbleStartBtn();
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        /*
         * 开始按钮的监听
         */
        btnStart.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                startTimer();
                btnStart.setVisibility(View.GONE);
                btnPause.setVisibility(View.VISIBLE);
                //btnReset.setVisibility(View.VISIBLE);
            }

        });
        /*
         * 暂停按钮
         */
        btnPause.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                stopTimer();
                btnPause.setVisibility(View.GONE);
                //btnResume.setVisibility(View.VISIBLE);
            }
        });
        /*
         * 继续按钮
         */
        //btnResume.setOnClickListener(new OnClickListener() {
        //
        //    @Override
        //    public void onClick(View v) {
        //        startTimer();
        //        btnResume.setVisibility(View.GONE);
        //        btnPause.setVisibility(View.VISIBLE);
        //
        //    }
        //});
        ///*
        // * 重置按钮
        // */
        //btnReset.setOnClickListener(new OnClickListener() {
        //
        //    @Override
        //    public void onClick(View v) {
        //        stopTimer();
        //        etHour.setText("0");
        //        etMin.setText("0");
        //        etSec.setText("0");
        //
        //        btnStart.setVisibility(View.VISIBLE);
        //        btnReset.setVisibility(View.GONE);
        //        btnResume.setVisibility(View.GONE);
        //        btnPause.setVisibility(View.GONE);
        //
        //    }
        //});

    }

    /**
     * 开始计时
     */
    private void startTimer() {
        if (task == null) {
            allTimeCount = Integer.parseInt(etHour.getText().toString()) * 60 * 60
                    + Integer.parseInt(etMin.getText().toString()) * 60
                    + Integer.parseInt(etSec.getText().toString());

            task = new TimerTask() {

                @Override
                public void run() {
                    allTimeCount--;
                    handler.sendEmptyMessage(WHAT2);
                    if (allTimeCount <= 0) {
                        handler.sendEmptyMessage(WHAT1);
                        stopTimer();
                    }

                }

            };
            //启动时间任务
            timer.schedule(task, 1000, 1000);

        }

    }

    /**
     * 停止计时
     */
    private void stopTimer() {
        if (task != null) {
            task.cancel();//相当于暂停
            task = null;
        }

    }

    Handler handler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case WHAT1:
                    new AlertDialog.Builder(getContext())
                            .setTitle("当前时间").setMessage("0")
                            .setNegativeButton("取消", null).show();

                    btnStart.setVisibility(View.VISIBLE);
                    //btnReset.setVisibility(View.GONE);
                    //btnResume.setVisibility(View.GONE);
                    btnPause.setVisibility(View.GONE);

                    break;

                case WHAT2:
                    int hour = allTimeCount / 60 / 60;//取整
                    int min = (allTimeCount / 60) % 60;//取余
                    int sec = allTimeCount % 60;//取余
                    etHour.setText(hour + "");
                    etMin.setText(min + "");
                    etSec.setText(sec + "");
                    break;
            }
        }

        ;

    };

    private static final int WHAT1 = 1;
    private static final int WHAT2 = 2;
    private int allTimeCount = 0;
    Timer timer = new Timer();
    TimerTask task = null;

    /**
     * 判断按钮是否能点
     */
    private void checkToAbleStartBtn() {

        btnStart.setEnabled((!TextUtils.isEmpty(etHour.getText()) && Integer.parseInt(etHour
                .getText().toString()) > 0)
                || (!TextUtils.isEmpty(etMin.getText()) && Integer.parseInt(etMin
                .getText().toString()) > 0)
                || (!TextUtils.isEmpty(etSec.getText()) && Integer.parseInt(etSec
                .getText().toString()) > 0));

    }

    /**
     * 初始化控件
     */
    private void initView() {
        etHour = (EditText) findViewById(R.id.etHour);
        etMin = (EditText) findViewById(R.id.etMin);
        etSec = (EditText) findViewById(R.id.etSec);
        btnStart = (Button) findViewById(R.id.btnStart);
        btnPause = (Button) findViewById(R.id.btnPause);
        //btnResume = (Button) findViewById(R.id.btnResume);
        //btnReset = (Button) findViewById(R.id.btnReset);
    }

}
