package com.tang.bottomnavigation.bottomnavigation.otheractivity;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.tang.bottomnavigation.bottomnavigation.R;

public class insert extends AppCompatActivity {
    private MyDBHelper dbHelper;
    private String username;
    private String userpassword;
    int userflag;//定义一个标示判断 用户名是否存在
    private EditText user;
    private EditText pwd;
    String name;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);
        user = (EditText) findViewById(R.id.editText);
        pwd = (EditText) findViewById(R.id.editText2);
    }

    public void insert() {
        dbHelper = new MyDBHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();    //建立打开可读可写的数据库实例
        //查询一下，是否用户名重复
        String sql1 = "select * from users";
        Cursor cursor = db.rawQuery(sql1, null);
        while (cursor.moveToNext()) {
            //第一列为id
            username = cursor.getString(0); //获取第2列的值,第一列的索引从0开始
            userpassword = cursor.getString(1);//获取第3列的值
            if ((user.getText().toString().isEmpty()) || (pwd.getText().toString().isEmpty())) {
                Toast.makeText(this, "不能为空，请重新输入", Toast.LENGTH_SHORT).show();
                break;
            }
            userflag = 1;  //不存在此用户
            if ((user.getText().toString().equals(name))) {
                Toast.makeText(this, "已存在此用户，请重新注册", Toast.LENGTH_SHORT).show();
                userflag = 0;
                break;
            }
        }
        if (userflag == 1) {
            String sql2 = "insert into users(name,pwd) values ('" + user.getText().toString() + "','" + pwd.getText().toString() + "')";
            db.execSQL(sql2);
            Toast.makeText(this, "注册成功！", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    public void handleinsert(View view) {
        insert();
    }
}