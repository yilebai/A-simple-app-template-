package com.tang.bottomnavigation.bottomnavigation.otheractivity;

import android.app.AlertDialog;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.tang.bottomnavigation.bottomnavigation.R;

import java.util.Timer;
import java.util.TimerTask;

public class offlineActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int WHAT1 = 1;
    private static final int WHAT2 = 2;
    private static final int WHAT3 = 3;

    private static final String TAG = "TAG";

    private EditText etHour, etMin, etSec;
    private Button btnStart, btnPause;

    private int allTimeCount = 0;


    Timer timer = new Timer();
    TimerTask task = null;

    Handler handler = new Handler() {
        MediaPlayer mMediaPlayer;
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case WHAT1:
                    mMediaPlayer=MediaPlayer.create(offlineActivity.this, R.raw.startoff);
                    mMediaPlayer.start();
                    break;
                case WHAT2:
                    int hour = allTimeCount / 60 / 60;//取整
                    int min = (allTimeCount / 60) % 60;//取余
                    int sec = allTimeCount % 60;//取余
                    etHour.setText(hour + "");
                    etMin.setText(min + "");
                    etSec.setText(sec + "");
                    break;
                case WHAT3:
                    mMediaPlayer.pause();
                    MediaPlayer mMediaPlayer2;
                    mMediaPlayer2=MediaPlayer.create(offlineActivity.this, R.raw.timeup);
                    mMediaPlayer2.start();
                    break;
            }
        }

        ;

    };

    private ImageView iv_hint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline);

        initViews();

        initListeners();
    }

    private void initListeners() {
        btnStart.setOnClickListener(this);
        btnPause.setOnClickListener(this);

        /*
         * 小时监听
         */
        etHour.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());

                    if (value > 59) {
                        etHour.setText("59");
                    } else if (value < 0) {
                        etHour.setText("0");
                    }
                    checkToAbleStartBtn();
                }

            }



            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        /*
         * 分钟监听
         */
        etMin.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());

                    if (value > 59) {
                        etMin.setText("59");
                    } else if (value < 0) {
                        etMin.setText("0");
                    }
                    checkToAbleStartBtn();
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        /*
         * 秒钟监听
         */
        etSec.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());

                    if (value > 59) {
                        etSec.setText("59");
                    } else if (value < 0) {
                        etSec.setText("0");
                    }
                    checkToAbleStartBtn();
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void initViews() {
        etHour = (EditText) findViewById(R.id.etHour);
        etMin = (EditText) findViewById(R.id.etMin);
        etSec = (EditText) findViewById(R.id.etSec);
        btnStart = (Button) findViewById(R.id.btnStart);
        btnPause = (Button) findViewById(R.id.btnPause);
        iv_hint = (ImageView) findViewById(R.id.iv_hint);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnStart:
                Log.d(TAG, "onClick: start");
                startOrPause();
                break;
            case R.id.btnPause:
                Log.d(TAG, "onClick: pause");
                reset();
                break;
        }
    }

    /**
     * 判断按钮是否能点
     */
    private void checkToAbleStartBtn() {

        btnStart.setEnabled((!TextUtils.isEmpty(etHour.getText()) && Integer.parseInt(etHour
                .getText().toString()) > 0)
                || (!TextUtils.isEmpty(etMin.getText()) && Integer.parseInt(etMin
                .getText().toString()) > 0)
                || (!TextUtils.isEmpty(etSec.getText()) && Integer.parseInt(etSec
                .getText().toString()) > 0));

    }

    private void reset() {
        stopTimer();

        etHour.setText("00");
        etMin.setText("00");
        etSec.setText("00");
        iv_hint.setImageResource(R.drawable.timetext1);
        btnStart.setBackgroundResource(R.drawable.kaishibutton);
    }

    private void startOrPause() {
        if (isStart()) {
            //已经开始了
            stopTimer();
            btnStart.setBackgroundResource(R.drawable.jixubutton);
        }else{
            startTimer();
            btnStart.setBackgroundResource(R.drawable.zantingbutton);
            iv_hint.setImageResource(R.drawable.timetext2);
        }
    }

    private boolean isStart() {
        return task!=null;
    }

    /**
     * 开始计时
     */
    private void startTimer() {
        if (task == null) {
            allTimeCount = Integer.parseInt(etHour.getText().toString()) * 60 * 60
                    + Integer.parseInt(etMin.getText().toString()) * 60
                    + Integer.parseInt(etSec.getText().toString());
            handler.sendEmptyMessage(WHAT1);//播放开始语音
            task = new TimerTask() {

                @Override
                public void run() {
                    allTimeCount--;
                    handler.sendEmptyMessage(WHAT2);
                     //当倒计时为0时：
                    if (allTimeCount <= 0) {
                        handler.sendEmptyMessage(WHAT3);//播放结束语音
                        stopTimer();
                        iv_hint.setImageResource(R.drawable.timetext3);
                        btnStart.setBackgroundResource(R.drawable.kaishibutton);
                    }

                }

            };

            //启动时间任务
            timer.schedule(task, 1000, 1000);

        }

    }

    /**
     * 停止计时
     */
    private void stopTimer() {
        if (task != null) {
            task.cancel();//相当于暂停
            task = null;
        }

    }
}
