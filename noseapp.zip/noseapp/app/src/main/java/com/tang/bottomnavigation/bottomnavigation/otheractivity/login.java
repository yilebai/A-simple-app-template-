package com.tang.bottomnavigation.bottomnavigation.otheractivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.tang.bottomnavigation.bottomnavigation.MainActivity;
import com.tang.bottomnavigation.bottomnavigation.R;

public class login extends AppCompatActivity {
    private MyDBHelper dbHelper;
    int loginflag;//登录时判断用户密码是否输入正确
    private EditText user;
    private EditText pwd;
    String name;
    String mypwd;
    SharedPreferences sp;
    private CheckBox checkBox;//是否保存密码的选择框
    private EditText edit_name, edit_psd;//用户名和密码的文本输入框
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sp = getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        dbHelper = new MyDBHelper(this);
        user = (EditText) findViewById(R.id.nameText);
        pwd = (EditText) findViewById(R.id.pswdText);
        checkBox = (CheckBox) findViewById(R.id.mima);
        btn = (Button) findViewById(R.id.login);
        output();//刚进入就先取一次，看看当然状态
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper = new MyDBHelper(getApplicationContext());
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                String sql = "select * from users";
                Cursor cursor = db.rawQuery(sql, null);
                while (cursor.moveToNext()) {
                    //第一列为id
                    name = cursor.getString(1); //获取第2列的值,第一列的索引从0开始
                    mypwd = cursor.getString(2);//获取第3列的值
                    if ((user.getText().toString().equals(name)) && (pwd.getText().toString().equals(mypwd))) {
                        loginflag = 1;
                        input();//登录成功就把数据存起来
                        Intent intent = new Intent(login.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
                if ((user.getText().toString().isEmpty()) || (pwd.getText().toString().isEmpty())) {

                    Toast.makeText(login.this, "不能为空，请重新输入", Toast.LENGTH_SHORT).show();
                }
                if (loginflag != 1) {
                    Toast.makeText(login.this, "账号或者密码错误,请重新输入", Toast.LENGTH_SHORT).show();
                }
                cursor.close();
                db.close();
            }
        });
    }

    private void output() {
        SharedPreferences shared = getSharedPreferences("mypsd", MODE_PRIVATE);
        String name1 = shared.getString("user", "");
        String psd1 = shared.getString("pwd", "");
        boolean ischecked1 = shared.getBoolean("isChecked", false);
        user.setText(name1);
        pwd.setText(psd1);
        checkBox.setChecked(ischecked1);
    }

    private void input() {
        SharedPreferences.Editor edit = getSharedPreferences("mypsd", MODE_PRIVATE).edit();
        //判断选择框的状态   被选中isChecked
        if (checkBox.isChecked()) {
            edit.putString("user", user.getText().toString());
            edit.putString("pwd", pwd.getText().toString());
            edit.putBoolean("isChecked", true);
        } else {
            edit.clear();
        }
        edit.commit();
    }

    public void insert() {

        Intent intent1 = new Intent();
        intent1.setClass(getApplicationContext(), insert.class);
        startActivity(intent1);
    }

    public void handleRegist(View view) {
        insert();
    }
}
