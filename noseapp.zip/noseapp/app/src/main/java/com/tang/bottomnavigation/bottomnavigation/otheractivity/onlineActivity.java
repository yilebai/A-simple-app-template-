package com.tang.bottomnavigation.bottomnavigation.otheractivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothManager;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.tang.bottomnavigation.bottomnavigation.Fragment1;
import com.tang.bottomnavigation.bottomnavigation.R;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

public class onlineActivity extends AppCompatActivity implements View.OnClickListener {
    private BluetoothManager bluetoothManager;  //蓝牙管理者
    private BluetoothAdapter bluetoothAdapter;//蓝牙适配器
    private BluetoothDevice bluetoothDevice;//蓝牙对象
    private BluetoothGatt bluetoothGatt; //蓝牙统筹对象
    private BluetoothGattCharacteristic characteristic;//蓝牙特征

    private UUID charatUUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");//特征uuid

    private static final int TIMEUP = 1;
    private static final int WHAT2 = 2;
    private static final int WHAT3 = 6;
    private static final int DARK = 3;
    private static final int EARS = 4;
    private static final int TOOCLOSE= 5;
    private static final String TAG = "TAG";
    private MediaPlayer mMediaPlayertest;
    private EditText etHour, etMin, etSec;
    private Button btnStart, btnPause;

    private int allTimeCount = 0;

    private int panduan2 = 0;
    private int panduan3 = 0;
    private int panduan4 = 0;

    Timer timer = new Timer();
    TimerTask task = null;

    Handler handler = new Handler() {
        MediaPlayer mMediaPlayer;
        MediaPlayer mMediaPlayer2;
        MediaPlayer mMediaPlayer3;
        MediaPlayer mMediaPlayer4;
        MediaPlayer mMediaPlayer5;
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case TIMEUP:
                    //new AlertDialog.Builder(getContext())
                    //        .setTitle("当前时间").setMessage("0")
                    //        .setNegativeButton("取消", null).show();
                    //
                    //btnStart.setVisibility(View.VISIBLE);
                    ////btnReset.setVisibility(View.GONE);
                    ////btnResume.setVisibility(View.GONE);
                    //btnPause.setVisibility(View.GONE);
                    if(panduan2==1){ mMediaPlayer2.pause();panduan2=0;}
                    if(panduan3==1){ mMediaPlayer3.pause();panduan3=0;}
                    if(panduan4==1){ mMediaPlayer4.pause();panduan4=0;}
                    mMediaPlayer5.pause();
                    mMediaPlayer=MediaPlayer.create(onlineActivity.this, R.raw.timeup);
                    mMediaPlayer.start();
                    break;

                case WHAT2:
                    int hour = allTimeCount / 60 / 60;//取整
                    int min = (allTimeCount / 60) % 60;//取余
                    int sec = allTimeCount % 60;//取余

                    etHour.setText(hour + "");
                    etMin.setText(min + "");
                    etSec.setText(sec + "");
                    break;
                case WHAT3:
                    mMediaPlayer5=MediaPlayer.create(onlineActivity.this, R.raw.starton);
                    mMediaPlayer5.start();
                    break;

                case EARS:
                    mMediaPlayer5.pause();

                    if(panduan2==1){ mMediaPlayer2.pause();panduan2=0;}
                    if(panduan3==1){ mMediaPlayer3.pause();panduan3=0;}
                    if(panduan4==1){ mMediaPlayer4.pause();panduan4=0;}
                    mMediaPlayer2=MediaPlayer.create(onlineActivity.this, R.raw.ears);
                    mMediaPlayer2.start();
                    panduan2=1;
                    break;

                case DARK:
                    mMediaPlayer5.pause();

                    if(panduan2==1){ mMediaPlayer2.pause();panduan2=0;}
                    if(panduan3==1){ mMediaPlayer3.pause();panduan3=0;}
                    if(panduan4==1){ mMediaPlayer4.pause();panduan4=0;}
                    mMediaPlayer3=MediaPlayer.create(onlineActivity.this, R.raw.dark);
                    mMediaPlayer3.start();
                    panduan3=1;
                    break;

                case TOOCLOSE:
                    mMediaPlayer5.pause();

                    if(panduan2==1){ mMediaPlayer2.pause();panduan2=0;}
                    if(panduan3==1){ mMediaPlayer3.pause();panduan3=0;}
                    if(panduan4==1){ mMediaPlayer4.pause();panduan4=0;}
                    mMediaPlayer4=MediaPlayer.create(onlineActivity.this, R.raw.tooclose);
                    mMediaPlayer4.start();
                    panduan4=1;
                    break;
            }
        }

        ;

    };
    private ImageView iv_hint;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 注销订阅者
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(Fragment1.MessageEvent event) {

        String message=event.getMessage();
        Log.d(TAG, "onMessageEvent: "+message);

        if (message.startsWith("3")) {
            //3开始
            //handler.sendEmptyMessage(EARS);//播放3号语音
           // mMediaPlayertest.pause();
            mMediaPlayertest=MediaPlayer.create(onlineActivity.this, R.raw.ears);
            mMediaPlayertest.start();
        } else if (message.startsWith("1")) {
            //1开始
            //mMediaPlayertest.pause();
            mMediaPlayertest=MediaPlayer.create(onlineActivity.this, R.raw.tooclose);
            mMediaPlayertest.start();
        }else if (message.startsWith("2")) {
            //1开始
            //mMediaPlayertest.pause();
            mMediaPlayertest=MediaPlayer.create(onlineActivity.this, R.raw.dark);
            mMediaPlayertest.start();
        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_online);
        initViews();
        initListeners();
        // 注册订阅者
        EventBus.getDefault().register(this);
    }

    private void initListeners() {
        btnStart.setOnClickListener(this);
        btnPause.setOnClickListener(this);

        /*
         * 小时监听
         */
        etHour.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());

                    if (value > 59) {
                        etHour.setText("59");
                    } else if (value < 0) {
                        etHour.setText("0");
                    }
                    checkToAbleStartBtn();
                }

            }



            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        /*
         * 分钟监听
         */
        etMin.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());

                    if (value > 59) {
                        etMin.setText("59");
                    } else if (value < 0) {
                        etMin.setText("0");
                    }
                    checkToAbleStartBtn();
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        /*
         * 秒钟监听
         */
        etSec.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(s)) {
                    int value = Integer.parseInt(s.toString());

                    if (value > 59) {
                        etSec.setText("59");
                    } else if (value < 0) {
                        etSec.setText("0");
                    }
                    checkToAbleStartBtn();
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void initViews() {
        etHour = (EditText) findViewById(R.id.etHour);
        etMin = (EditText) findViewById(R.id.etMin);
        etSec = (EditText) findViewById(R.id.etSec);
        btnStart = (Button) findViewById(R.id.btnStart);
        btnPause = (Button) findViewById(R.id.btnPause);
        iv_hint = (ImageView) findViewById(R.id.iv_hint);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnStart:
                Log.d(TAG, "onClick: start");
                startOrPause();
                break;
            case R.id.btnPause:
                Log.d(TAG, "onClick: pause");
                reset();
                break;
        }
    }

    /**
     * 判断按钮是否能点
     */
    private void checkToAbleStartBtn() {

        btnStart.setEnabled((!TextUtils.isEmpty(etHour.getText()) && Integer.parseInt(etHour
                .getText().toString()) > 0)
                || (!TextUtils.isEmpty(etMin.getText()) && Integer.parseInt(etMin
                .getText().toString()) > 0)
                || (!TextUtils.isEmpty(etSec.getText()) && Integer.parseInt(etSec
                .getText().toString()) > 0));

    }

    private void reset() {
        stopTimer();

        etHour.setText("00");
        etMin.setText("00");
        etSec.setText("00");
        iv_hint.setImageResource(R.drawable.timetext1);
        btnStart.setBackgroundResource(R.drawable.kaishibutton);
    }

    private void startOrPause() {
        if (isStart()) {
            //已经开始了
            stopTimer();

            btnStart.setBackgroundResource(R.drawable.jixubutton);
        }else{
            startTimer();
            btnStart.setBackgroundResource(R.drawable.zantingbutton);
            iv_hint.setImageResource(R.drawable.timetext2);
        }
    }

    private boolean isStart() {
        return task!=null;
    }

    /**
     * 开始计时
     */
    private void startTimer() {
        if (task == null) {
            allTimeCount = Integer.parseInt(etHour.getText().toString()) * 60 * 60
                    + Integer.parseInt(etMin.getText().toString()) * 60
                    + Integer.parseInt(etSec.getText().toString());
            handler.sendEmptyMessage(WHAT3);
            task = new TimerTask() {

                @Override
                public void run() {
                    allTimeCount--;
                    handler.sendEmptyMessage(WHAT2);
                    //当倒计时为0时：
                    if (allTimeCount <= 0) {
                        handler.sendEmptyMessage(TIMEUP);
                        stopTimer();
                        iv_hint.setImageResource(R.drawable.timetext3);
                        btnStart.setBackgroundResource(R.drawable.kaishibutton);
                    }

                }

            };

            //启动时间任务
            timer.schedule(task, 1000, 1000);

        }

    }

    /**
     * 停止计时
     */
    private void stopTimer() {
        if (task != null) {
            task.cancel();//相当于暂停
            task = null;
        }

    }
/*
    final Intent intent = new Intent(action);
    //从特征值获取数据
    final byte[] data = characteristic.getValue();
        if (data != null && data.length > 0)
    {
        final StringBuilder stringBuilder = new StringBuilder(data.length);
        for (byte byteChar : data)
        {
            stringBuilder.append(String.format("%02X ", byteChar));

            Log.i(TAG, "***broadcastUpdate: byteChar = " + byteChar);

        }
        intent.putExtra(EXTRA_DATA, new String(data));
        System.out.println("broadcastUpdate for  read data:"
                + new String(data));
    }
*/


}
