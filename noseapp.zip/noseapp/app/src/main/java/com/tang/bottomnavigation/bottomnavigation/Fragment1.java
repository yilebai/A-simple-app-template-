package com.tang.bottomnavigation.bottomnavigation;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.tang.bottomnavigation.bottomnavigation.otheractivity.offlineActivity;
import com.tang.bottomnavigation.bottomnavigation.otheractivity.onlineActivity;

import org.greenrobot.eventbus.EventBus;

import java.util.List;
import java.util.Random;
import java.util.UUID;


import static com.tang.bottomnavigation.bottomnavigation.otheractivity.BluetoothLeService.EXTRA_DATA;

//对象实例化（android BLE4.0开发，必须是4.3以上的机子才能支持。）
//搜索 （mac 唯一）
//匹配蓝牙，连接蓝牙(decription(描述),services(服务),characteristic(特征))、
//services--》characteristic---》响应(characteristic read write nodify)
//设置characteristic 桥梁，发送指令
//接收指令
public class Fragment1 extends Fragment {
    private static final int WHAT1 = 1;
    private static final int WHAT2 = 2;
    private static final String TAG = "Fragment1";
    private BluetoothManager bluetoothManager;  //蓝牙管理者
    private BluetoothAdapter bluetoothAdapter;//蓝牙适配器
    private BluetoothDevice bluetoothDevice;//蓝牙对象
    private BluetoothGatt bluetoothGatt; //蓝牙统筹对象
    private BluetoothGattCharacteristic characteristic;//蓝牙特征
    public final static String ACTION_DATA_AVAILABLE = "com.hc_ble.bluetooth.le.ACTION_DATA_AVAILABLE";

    private UUID charatUUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");//特征uuid

    private Button btlink;
    private Button bt1;
    private Button bt2;
    private int bluetooth = 0;

    // 蓝牙扫描时间
    // 10秒
    private static final long SCAN_PERIOD = 10000;

    BluetoothGatt gatt;
    @SuppressLint("HandlerLeak")
    Handler handler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            btlink = (Button) getView().findViewById(R.id.btlink);
            switch (msg.what) {
                case WHAT1:
                    bluetooth = 1;
                    Toast.makeText(getActivity(), "设备已连接", Toast.LENGTH_SHORT).show();
                    btlink.setBackgroundResource(R.drawable.linkselector);
                    /*
                    String value1 = String.valueOf(1);
                    //发送数据
                    characteristic.setValue(value1);
                    bluetoothGatt.writeCharacteristic(characteristic);
                    */
                    break;

                case WHAT2:
                    bluetooth = 0;
                    Toast.makeText(getActivity(), "设备未连接,请先点击右上角状态按钮进行扫描", Toast.LENGTH_SHORT).show();
                    btlink.setBackgroundResource(R.drawable.nolinkselector);
                    /*
                    String value2 = String.valueOf(0);
                    //发送数据
                    characteristic.setValue(value2);
                    bluetoothGatt.writeCharacteristic(characteristic);
                    */
                    break;
            }
        }

        ;
    };
    private boolean isScan;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fragment1, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();
        startScan();
    }

    public class MessageEvent {//定义事件
        private String message;

        public MessageEvent(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    //private void initViews() {
        //btlink = (Button) getView().findViewById(R.id.btlink);
    //}
        //btlink.setOnClickListener(new View.OnClickListener(){});
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //实例化对象
        bluetoothManager = (android.bluetooth.BluetoothManager) getActivity().getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter(); //实例化蓝牙适配器
        bluetoothAdapter.enable();//让用户把蓝牙打开

        btlink= getView().findViewById(R.id.btlink);
        btlink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onScanClick");
                Toast.makeText(getActivity(), "正在为您扫描并连接设备", Toast.LENGTH_SHORT).show();
                startScan();
            }
        });

        //打开新界面
        bt1 = getView().findViewById(R.id.bt1);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent可以翻译为意图
                // 意图是干什么，做什么的意思
                // 其实他就是个类
                // 这里我们启动SecondActivity
                if (bluetooth == 1) {
                    //判断设备是否已经连接
                    //characteristic.setValue("1");
                    //gatt.writeCharacteristic(characteristic);

                    //////////////////////
                    /*
                    String value1 = String.valueOf(1);
                    //发送数据
                    characteristic.setValue(value1);
                    bluetoothGatt.writeCharacteristic(characteristic);
                    */
                    //////////////////////

                    Intent intent = new Intent(getActivity(), onlineActivity.class);///
                    // 启动这个意图里面的activity
                    startActivity(intent);
                } else {
                    Toast.makeText(getActivity(), "设备未连接,请先点击右上角状态按钮进行扫描", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //打开新界面
        bt2 = getView().findViewById(R.id.bt2);
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                // Intent可以翻译为意图
//                // 意图是干什么，做什么的意思
//                // 其实他就是个类
//                // 这里我们启动SecondActivity
//                Intent intent = new Intent(getActivity(), offlineActivity.class);
//                // 启动这个意图里面的activity
//                startActivity(intent);
                // Intent可以翻译为意图
                // 意图是干什么，做什么的意思
                // 其实他就是个类
                // 这里我们启动SecondActivity
                if (bluetooth == 1) {
                    //判断设备是否已经连接
                    //characteristic.setValue("1");
                    //gatt.writeCharacteristic(characteristic);

                    //////////////////////
                    /*
                    String value1 = String.valueOf(1);
                    //发送数据
                    characteristic.setValue(value1);
                    bluetoothGatt.writeCharacteristic(characteristic);
                    */
                    //////////////////////

                    Intent intent = new Intent(getActivity(), onlineActivity.class);///
                    // 启动这个意图里面的activity
                    startActivity(intent);
                } else {
                    Toast.makeText(getActivity(), "设备未连接,请先点击右上角状态按钮进行扫描", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    //搜索到蓝牙回调
    private BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback() {
        @Override
        public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
            Log.d("ble", "onLeScan："+device.getName()+" mac:"+device.getAddress());

            // TODO Auto-generated method stub
            //if ("CGeyes".equals(device.getName())) {
            if ("CGeyes".equals(device.getName())) {
                bluetoothDevice = device;
                Log.d(TAG, "我的蓝牙设备：" + device.getName() + " mac:" + device.getAddress());
                Toast.makeText(getActivity(), "设备连接中", Toast.LENGTH_SHORT).show();
                bluetoothGatt = bluetoothDevice.connectGatt(getActivity(), false, mGattCallback);

                //扫描到需要的设备
                //停止扫描
                stopScan();
            }
        }
    };
    //蓝牙连接回调
    private BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        //蓝牙连接状态表达
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.d(TAG, "连接蓝牙");
                bluetoothGatt.discoverServices();
                handler.sendEmptyMessage(WHAT1);

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.d(TAG, "断开蓝牙");
                handler.sendEmptyMessage(WHAT2);

            }
        }

        ;

        //找到服务
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            List<BluetoothGattService> services = bluetoothGatt.getServices();
            Log.d(TAG, "找到服务");

            for (BluetoothGattService service : services) {
                characteristic = service.getCharacteristic(charatUUID);
                if (characteristic != null) {

                    Log.d(TAG, "发现特征");

                    //设置characteristic
                    bluetoothGatt.setCharacteristicNotification(characteristic, true);

                    ///////////////////////下面三行代码用来发送数据
                    String value1 = String.valueOf(1);
                    //发送数据
                    characteristic.setValue(value1);
                    bluetoothGatt.writeCharacteristic(characteristic);
                    ////////////////////////
                }
            }
        }

        ;

        //蓝牙读取指令回调
        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status)
        {
            //从特征值获取数据
            final byte[] data = characteristic.getValue();
            if (data != null && data.length > 0)
            {
                final StringBuilder stringBuilder = new StringBuilder(data.length);
                for (byte byteChar : data)
                {
                    stringBuilder.append(String.format("%02X ", byteChar));

                    Log.i(TAG, "***broad+castUpdate: byteChar = " + byteChar);

                }

                String result=new String(data);

                System.out.println("broadcastUpdate for  read data:"
                        + result);


            }
        }



/*
        //广播意图
        private void broadcastUpdate(final String action, int rssi)
        {
            final Intent intent = new Intent(action);
            intent.putExtra(EXTRA_DATA, String.valueOf(rssi));
            sendBroadcast(intent);
        }
        //广播意图
        private void broadcastUpdate(final String action)
        {
            final Intent intent = new Intent(action);
            sendBroadcast(intent);
        }

        // 广播远程发送过来的数据
        public void broadcastUpdate(final String action,
                                    final BluetoothGattCharacteristic characteristic)
        {
            final Intent intent = new Intent(action);
            //从特征值获取数据
            final byte[] data = characteristic.getValue();
            if (data != null && data.length > 0)
            {
                final StringBuilder stringBuilder = new StringBuilder(data.length);
                for (byte byteChar : data)
                {
                    stringBuilder.append(String.format("%02X ", byteChar));

                    Log.i(TAG, "***broadcastUpdate: byteChar = " + byteChar);

                }
                intent.putExtra(EXTRA_DATA, new String(data));
                System.out.println("broadcastUpdate for  read data:"
                        + new String(data));
            }
            sendBroadcast(intent);
        }
*/
        //蓝牙写入指令回调
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {

        }


        //蓝牙返回指令回调
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            processMessage(characteristic);

        }
    };

    private synchronized void processMessage(BluetoothGattCharacteristic characteristic) {
        long end=System.currentTimeMillis();
        if (end-start<5000) {
            Log.d(TAG, "onCharacteristicChanged: ignore");
            return;
        }

        start=end;

        byte[] data = characteristic.getValue();
        String valueString = new String(data);
        Log.d(TAG, "onCharacteristicChanged::"+valueString);

        if (!TextUtils.isEmpty(valueString)) {
            //只有 有数据才发送
            EventBus.getDefault().post(new MessageEvent(valueString));
        }
    }

    private long start=0;
    /*
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_study, menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

                case R.id.action_send:
                onSendClick();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void onSendClick() {
        Log.d(TAG, "onSendClick");

        if (characteristic == null) {
            Toast.makeText(getActivity(), "请先连接设备！", Toast.LENGTH_SHORT).show();
            return;
        }

        //随机产生一个值
        String value = String.valueOf(1);

        //发送数据
        characteristic.setValue(value);

        bluetoothGatt.writeCharacteristic(characteristic);
    }
    private void sendnumber(int num) {
        String value = String.valueOf(num);

        //发送数据
        characteristic.setValue(value);

        bluetoothGatt.writeCharacteristic(characteristic);
    };
    */
    private void startScan() {
        if (isScan) {
            //正在扫描
            //就返回
            //真实项目中应该控制按钮不能点击这样的操作
            Log.w(TAG, "already startScan");
            return;
        }

        Log.d(TAG, "startScan");

        isScan = true;

        //TextView textView = getView().findViewById(R.id.textOne);
        bluetoothAdapter.startLeScan(mLeScanCallback);

        //延时停止扫描
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                stopScan();
                isScan = false;
            }
        }, SCAN_PERIOD);
    }

    private void stopScan() {
        Log.d(TAG, "stopScan");
        bluetoothAdapter.stopLeScan(mLeScanCallback);
    }


}

